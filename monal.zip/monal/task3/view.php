<?php
	require_once "connect.php";
	$response=array();
	$var1=mysqli_query($conn, "select * from appointment ") or die(mysqli_error($conn));
	if(mysqli_num_rows($var1)>0){
		while($row=mysqli_fetch_assoc($var1)){
			array_push($response,array(
			"id"=>$row["id"],
	"name"=>$row["name"],
	"mobile"=>$row["mobile"],
	"purpose"=>$row["purpose"],
	"status"=>$row["status"]));
	}
	echo json_encode($response);
}
?>

