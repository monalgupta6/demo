<!DOCTYPE html>
<html>
<head>
	<title>
	</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
      <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
      <style>
      	.container{
      		padding:100px;
      	}
      </style>
</head>
<body>
	<div class="container">
	<button type="button" value="add" id="add"  onclick="myFunction()">Add</button>
	<button type="button" value="save" id="save" >Save</button>
	<div id="data_0121324375435"></div>
		
	<hr>
	<div id="data_456481324375435"></div>

<script>


function myFunction() {
	var data='';
	var rand= Math.random(5);
  data = '<div class="row" id="data_'+rand+'"><button type="button" onclick="addFunction('+rand+')">+</button><select id="data1_'+rand+'" ></select><button type="button" onclick="rmFunction('+rand+')">-</button></div>';

  document.getElementById("data_0121324375435").innerHTML += data;


}
</script>
<script>
	this.addEventListener("change", myFunction1);

function myFunction1() {

	var elems = document.getElementsByTagName("select");
for(var i = 0; i < elems.length; i++) {
    elems[i].disabled = true;
}
 	
	 var x = document.getElementsByTagName("select")[0].getAttribute("id"); 

	  document.getElementsByTagName("select")[0].disabled = false;
	 
}




</script>



<script>
function addFunction(value){
$.getJSON('data.json', function(abc) {
                   var a=abc.myList;
                   var data='';
                   for(var i=0; i<a.length; i++)
                   {
                     data += '<option value="'+a[i].value+'" >'+a[i].label+'</option>';
                     
                    
                      console.log(a);
                   }
                   document.getElementById("data1_"+value).innerHTML=data;

               });
			

}
</script>
<script>
function rmFunction(value){
	
	
	
	document.getElementById("data_"+value).remove();

}
</script>
<script>
$(document).ready(function(){
  $("#save").click(function(){
    $("#data_0121324375435").clone().appendTo("#data_456481324375435");
  });
});
</script>

</div>
</body>
</html>