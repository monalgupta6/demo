
<!DOCTYPE html>
<html>
<head>
<style>
table, td {
  border: 1px solid black;
}
</style>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">


</head>
<body>

<p>Click the buttons to create row(s) for the table.</p>
<h3 align="center">View Records</h3>


<button onclick="myFunction()">Create row</button>


<script>
  var a;
function myFunction() {
/*a +='<tr><td>column1</td><td>column2</td><td>column3</td></tr>';
  $('#myTable').html(a);*/

    // get data through AJAX in alert.
   $.get("view.php", function(data, status){
      alert("Data: " + data + "\nStatus: " + status);
    });




 
}

</script>
 <div class="container">
  <table class="table table-bordered table-striped" id="table">
    <thead>
        <tr>
        <th><strong>ID</strong></th>
        <th><strong>User Name</strong></th>
        <th><strong>Email</strong></th>
        <th><strong>Phone Number</strong></th> 
        </tr>
    </thead>
    <tbody id="demo-table-content">
    
    </tbody>

  </table>
 </div>
 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
 
 <script>
   function myFunction(){
      /*parse data*/
      var json_data='';
     $.get("view.php",function(data, status){
      
     var a= JSON.parse(data);

     for(var i=0; i<a.length; i++){
      console.log(a[i].email);
       json_data += '<tr>'+
       '<td>'+a[i].id+'</td>'+
      '<td>'+a[i].username+'</td>'+
      '<td>'+a[i].email+'</td>'+
      '<td>'+a[i].phonenumber+'</td>'+
      '</tr>';
     }
     
     //append data
      $(json_data).appendTo('#demo-table-content');
     });
   /* $.getJSON("view.php", function(data){
            var json_data;
            console()
      $.each(data, function(key, value){
       

      });*/
  

  }
  </script>
</body>

</html>
