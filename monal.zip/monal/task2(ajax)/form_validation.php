<!DOCTYPE html>
<html>
	<head>
		<title>Form Validation</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		 <link rel="stylesheet" href="css/parsley.css">

		<style>
			.container{
				
				margin:auto;
				padding:100px;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<h2>Form Validation</h2>
		<form id="demo-form" data-parsley-validate="" method="post" >
			<div class="form-group">
			<label>UserName</label>
			<input type="text" name="username" id="username" class="form-control" placeholder="Enter username" data-parsley-pattern="^[A-Za-z]*$" data-parsley-trigger="keyup" data-parsley-pattern-message="Name should be in alphabet">
		</div>
		<div class="form-group">
			<label>Email</label>
			<input type="email" name="email" id="email" class="form-control" placeholder="Enter username"  data-parsley-type="email" data-parsley-trigger="change" required="" data-parsley-type-message="Email should be in format: yourname@example.com">
		</div>
		<div class="form-group">
			<label>ContactNumber</label>
			<input type="text" name="phonenumber" id="contactnumber" class="form-control" placeholder="Enter Contact Number" required="" data-parsley-minlength="10" data-parsley-maxlength="10" data-parsley-type="digits" data-parsley-type-message="only digits" data-parsley-trigger="keyup" data-parsley-maxlength-message="10 digits only" data-parsley-minlength-message="10 digits only">
		</div>
		<div class="form-group">
			<label>Password</label>
			<input type="password" name="password" id="password" class="form-control" placeholder="Enter password" data-parsley-equalto="#confirmpassword" data-required="" data-parsley-minlength="7" data-parsley-type-message="Password should have atleast 7 characters" data-parsley-trigger="keyup" >
		</div>
		<div class="form-group">
			<label>Confirm Password</label>
			<input type="password" name="confirmpassword" id="confirmpassword" class="form-control" placeholder="Confirm password" data-required="" data-parsley-minlength="7" data-parsley-type-message="Password should match"  data-parsley-equalto="#password">
		</div>

		<input type="button" name="submit" id="submitdata" value="submit" class="btn btn-success">
		<p>Do you have already an account?<a href="login.php">Login Here</a></p>
		<div id="my_pass"></div>
	</form>
	</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

<script src="js/parsley.min.js"></script>

<script type="text/javascript">
$(function () {
  $('#demo-form').parsley().on('field:validated', function() {
    var ok = $('.parsley-error').length === 0;
    $('.bs-callout-info').toggleClass('hidden', !ok);
    $('.bs-callout-warning').toggleClass('hidden', ok);
  })
  .on('form:submit', function() {
    return true; 
  });
});
</script>

<script type='text/javascript'>
 $(document).ready(function() {

    
    $('#submitdata').click(function(event) {

    	var user=$("input#username").val();
    	var email=$("input#email").val();
    	var phn=$("input#contactnumber").val();
    	//alert(phn);
    	var pass=$("input#password").val();
        var cnpass=$("input#confirmpassword").val();
        //alert(user);
      
       $.post("http://localhost/monal/task2/code_form_validation.php",
  		{
  			//value get from form (name of input type) : new var
   	 		username: user,
    		email: email,
    		phonenumber: phn,
    		password: pass,
    		confirmpassword: cnpass
  		},
  		function(data, status){
    	alert("Data: " + data + "\nStatus: " + status);
 		 });

        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
    });

});
</script>

	</body>

</html>
