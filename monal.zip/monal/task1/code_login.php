<?php
	session_start();

	require_once "connect.php";
	if(isset($_POST['submit'])){
		$email=$_POST['email'];
		$pass=$_POST['password'];


		if($_POST['email']==NULL or trim($_POST['email'])==NULL or !filter_var($email, FILTER_VALIDATE_EMAIL))
		{
			echo "invalid email";
			header("location:login.php");
		}
		elseif($_POST['password']==NULL or trim($_POST['password'])==NULL){
			echo "invalid password";
			header("location:login.php");
		}



	else{
		$var=mysqli_query($conn,"select * from user where email='$email'") or die(mysqli_error());
		if(mysqli_num_rows($var)>0){
			$res=mysqli_fetch_assoc($var);
			$password=$res['password'];
			if($password==$pass){
				$_SESSION['user']=$res['id'];
				echo "Password match";
				header("location:welcome.php");
			}
			else{
				echo "Error: password did not match";
			}

		}else{
			echo "Error: email is wrong";
		}


	}
	}



?>