<!DOCTYPE html>
<html>
<body>

<h2>JavaScript Array Sort</h2>

<p>Click the button to sort the array.</p>

<button onclick="myFunction()">Sort the array.</button>

<p id="demo"></p>

<script>
var points = [34,7,23,32,5,62];
document.getElementById("demo").innerHTML = points;  

function myFunction() {
  points.sort(function(a, b){return a - b});
  document.getElementById("demo").innerHTML = points;
}
</script>

</body>
</html>